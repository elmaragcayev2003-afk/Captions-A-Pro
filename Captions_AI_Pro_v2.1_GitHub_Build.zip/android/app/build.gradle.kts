plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace="com.captionsai.pro"; compileSdk=35
 defaultConfig { applicationId="com.captionsai.pro"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0.0" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.appcompat:appcompat:1.7.0")
 implementation("com.google.android.material:material:1.12.0")
 implementation("androidx.activity:activity-ktx:1.10.0")
 implementation("androidx.media3:media3-exoplayer:1.11.0")
 implementation("androidx.media3:media3-ui:1.11.0")
 implementation("androidx.media3:media3-transformer:1.11.0")
 implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}