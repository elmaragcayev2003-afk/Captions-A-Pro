package com.captionsai.pro

import android.content.*
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

data class Caption(var id:String=UUID.randomUUID().toString(),var start:Double,var end:Double,var text:String)

class MainActivity:AppCompatActivity(){
 private lateinit var player:ExoPlayer; private var videoUri:Uri?=null
 private val captions=mutableListOf<Caption>(); private val history=ArrayDeque<List<Caption>>()
 private lateinit var list:LinearLayout; private lateinit var status:TextView; private lateinit var live:TextView
 private val prefs by lazy{getSharedPreferences("captions_ai",MODE_PRIVATE)}
 private val pickVideo=registerForActivityResult(ActivityResultContracts.OpenDocument()){u-> if(u!=null){videoUri=u; runCatching{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION)};player.setMediaItem(MediaItem.fromUri(u));player.prepare();findViewById<Button>(R.id.analyze).isEnabled=true;status.text="Video hazır • AI altyazı oluşturabilirsiniz"}}
 private val saveFile=registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")){u->if(u!=null)contentResolver.openOutputStream(u)?.use{it.write(toSrt().toByteArray())}}
 private val saveMp4=registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")){u->if(u!=null) lifecycleScope.launch{exportMp4(u)}}
 override fun onCreate(s:Bundle?){super.onCreate(s);setContentView(R.layout.activity_main);player=ExoPlayer.Builder(this).build();findViewById<androidx.media3.ui.PlayerView>(R.id.player).player=player
  status=findViewById(R.id.status);live=findViewById(R.id.liveCaption);list=findViewById(R.id.captionList)
  val spin=findViewById<Spinner>(R.id.language);spin.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("auto","az","tr","ru","en","de","es","fr","it","uk"))
  findViewById<Button>(R.id.pick).setOnClickListener{pickVideo.launch(arrayOf("video/*"))};findViewById<Button>(R.id.analyze).setOnClickListener{transcribe(spin.selectedItem.toString())};findViewById<Button>(R.id.settings).setOnClickListener{serverDialog()}
  findViewById<Button>(R.id.add).setOnClickListener{snapshot();captions.add(Caption(start=0.0,end=2.0,text="Yeni altyazı"));render()};findViewById<Button>(R.id.undo).setOnClickListener{if(history.isNotEmpty()){captions.clear();captions.addAll(history.removeLast().map{it.copy()});render()}}
  findViewById<Button>(R.id.srt).setOnClickListener{saveFile.launch("captions.srt")};findViewById<Button>(R.id.export).setOnClickListener{if(videoUri==null||captions.isEmpty()){toast("Önce video ve altyazı gerekli")}else saveMp4.launch("captions_ai_export.mp4")}
  player.addListener(object:androidx.media3.common.Player.Listener{override fun onIsPlayingChanged(p:Boolean){if(p)tick()}})
 }
 private fun apiBase()=prefs.getString("server","https://YOUR-SERVER.example.com")!!.trimEnd('/')
 private fun apiKey()=prefs.getString("key","")!!
 private fun serverDialog(){val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;val url=EditText(this);url.hint="https://api.example.com";url.setText(apiBase());val key=EditText(this);key.hint="API key (opsiyonel)";key.setText(apiKey());box.setPadding(48,16,48,0);box.addView(url);box.addView(key);AlertDialog.Builder(this).setTitle("AI Server").setMessage("Telefonun erişebildiği HTTPS backend adresini girin.").setView(box).setPositiveButton("Kaydet"){_,_->prefs.edit().putString("server",url.text.toString()).putString("key",key.text.toString()).apply();healthCheck()}.setNegativeButton("İptal",null).show()}
 private fun healthCheck(){lifecycleScope.launch{status.text="Sunucu kontrol ediliyor...";try{val t=withContext(Dispatchers.IO){val c=(URL(apiBase()+"/health").openConnection() as HttpURLConnection);if(apiKey().isNotBlank())c.setRequestProperty("X-API-Key",apiKey());c.inputStream.bufferedReader().readText()};status.text="Sunucu hazır ✓"}catch(e:Exception){status.text="Sunucuya ulaşılamadı: ${e.message}"}}}
 private fun tick(){live.postDelayed(object:Runnable{override fun run(){val t=player.currentPosition/1000.0;live.text=captions.firstOrNull{t>=it.start&&t<it.end}?.text?:"";if(player.isPlaying)live.postDelayed(this,80)}},80)}
 private fun snapshot(){history.addLast(captions.map{it.copy()});while(history.size>30)history.removeFirst()}
 private fun transcribe(lang:String){val u=videoUri?:return;lifecycleScope.launch{try{status.text="AI dinliyor ve zamanlamaları oluşturuyor...";val r=withContext(Dispatchers.IO){multipart("/api/transcribe",u,mapOf("language" to lang))};snapshot();captions.clear();val a=r.getJSONArray("captions");for(i in 0 until a.length()){val o=a.getJSONObject(i);captions.add(Caption(o.optString("id",UUID.randomUUID().toString()),o.getDouble("start"),o.getDouble("end"),o.getString("text")))};render();status.text="Tamamlandı • ${captions.size} caption"}catch(e:Exception){status.text="AI hata: ${e.message}"}}}
 private fun render(){list.removeAllViews();captions.forEachIndexed{i,c->val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(12,12,12,12);val time=LinearLayout(this);val st=EditText(this);st.hint="Başla";st.setText("%.2f".format(c.start));val en=EditText(this);en.hint="Bitir";en.setText("%.2f".format(c.end));val del=Button(this);del.text="Sil";time.addView(st,LinearLayout.LayoutParams(0,-2,1f));time.addView(en,LinearLayout.LayoutParams(0,-2,1f));time.addView(del);val text=EditText(this);text.setText(c.text);text.setSingleLine(false);val save=Button(this);save.text="Zamanla";save.setOnClickListener{snapshot();c.start=st.text.toString().replace(',','.').toDoubleOrNull()?:c.start;c.end=en.text.toString().replace(',','.').toDoubleOrNull()?:c.end;c.text=text.text.toString().trim();player.seekTo((c.start*1000).toLong());status.text="Caption güncellendi"};del.setOnClickListener{snapshot();captions.removeAt(i);render()};box.addView(time);box.addView(text);box.addView(save);list.addView(box)}}
 private fun multipart(path:String,u:Uri,fields:Map<String,String>):JSONObject{val b="----Captions${System.currentTimeMillis()}";val c=(URL(apiBase()+path).openConnection() as HttpURLConnection);c.requestMethod="POST";c.doOutput=true;c.connectTimeout=30000;c.readTimeout=900000;c.setRequestProperty("Content-Type","multipart/form-data; boundary=$b");if(apiKey().isNotBlank())c.setRequestProperty("X-API-Key",apiKey());DataOutputStream(c.outputStream).use{out->fun w(s:String)=out.writeBytes(s);fields.forEach{(k,v)->w("--$b\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n")};w("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"input.mp4\"\r\nContent-Type: video/mp4\r\n\r\n");contentResolver.openInputStream(u)!!.use{it.copyTo(out)};w("\r\n--$b--\r\n")};if(c.responseCode !in 200..299)throw Exception(c.errorStream?.bufferedReader()?.readText()?:"HTTP ${c.responseCode}");return JSONObject(c.inputStream.bufferedReader().readText())}
 private fun exportMp4(dest:Uri){try{status.text="MP4 hazırlanıyor... bu işlem videoya göre sürebilir";val u=videoUri?:return;val b="----Export${System.currentTimeMillis()}";val c=(URL(apiBase()+"/api/export/mp4").openConnection() as HttpURLConnection);c.requestMethod="POST";c.doOutput=true;c.readTimeout=3600000;c.setRequestProperty("Content-Type","multipart/form-data; boundary=$b");if(apiKey().isNotBlank())c.setRequestProperty("X-API-Key",apiKey());DataOutputStream(c.outputStream).use{out->fun w(s:String)=out.writeBytes(s);w("--$b\r\nContent-Disposition: form-data; name=\"captions_json\"\r\n\r\n${captionsJson()}\r\n");w("--$b\r\nContent-Disposition: form-data; name=\"style_json\"\r\n\r\n{\"fontSize\":22}\r\n");w("--$b\r\nContent-Disposition: form-data; name=\"video\"; filename=\"input.mp4\"\r\nContent-Type: video/mp4\r\n\r\n");contentResolver.openInputStream(u)!!.use{it.copyTo(out)};w("\r\n--$b--\r\n")};if(c.responseCode !in 200..299)throw Exception(c.errorStream?.bufferedReader()?.readText()?:"HTTP ${c.responseCode}");contentResolver.openOutputStream(dest)!!.use{out->c.inputStream.use{it.copyTo(out)}};status.text="MP4 export tamamlandı ✓"}catch(e:Exception){status.text="Export hata: ${e.message}"}}
 private fun captionsJson():String{val a=JSONArray();captions.forEach{a.put(JSONObject().put("start",it.start).put("end",it.end).put("text",it.text))};return a.toString()}
 private fun toSrt()=captions.mapIndexed{i,c->"${i+1}\n${fmt(c.start)} --> ${fmt(c.end)}\n${c.text}\n"}.joinToString("\n")
 private fun fmt(v:Double):String{val ms=(v*1000).toLong();return "%02d:%02d:%02d,%03d".format(ms/3600000,(ms%3600000)/60000,(ms%60000)/1000,ms%1000)}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show();override fun onDestroy(){player.release();super.onDestroy()}
}
