import os, tempfile, subprocess, json, uuid
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Header, BackgroundTasks
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from faster_whisper import WhisperModel

MAX_BYTES=int(os.getenv('MAX_UPLOAD_MB','1024'))*1024*1024
API_KEY=os.getenv('API_KEY','').strip()
MODEL_SIZE=os.getenv('WHISPER_MODEL','small')
DEVICE=os.getenv('WHISPER_DEVICE','cpu')
COMPUTE=os.getenv('WHISPER_COMPUTE','int8')
OUT=Path(os.getenv('OUTPUT_DIR','/tmp/captions-output')); OUT.mkdir(parents=True,exist_ok=True)
model=None
app=FastAPI(title='Captions AI Pro API',version='2.0.0')
app.add_middleware(CORSMiddleware,allow_origins=os.getenv('CORS_ORIGINS','*').split(','),allow_methods=['GET','POST'],allow_headers=['*'])

def auth(key: Optional[str]):
    if API_KEY and key != API_KEY: raise HTTPException(401,'Invalid API key')

def get_model():
    global model
    if model is None: model=WhisperModel(MODEL_SIZE,device=DEVICE,compute_type=COMPUTE)
    return model

def ts(v):
    ms=max(0,round(float(v)*1000)); h=ms//3600000; m=(ms%3600000)//60000; s=(ms%60000)//1000; x=ms%1000
    return f'{h:02d}:{m:02d}:{s:02d},{x:03d}'

def cleanup(path: Path):
    try: path.unlink(missing_ok=True)
    except Exception: pass

@app.get('/health')
def health(): return {'ok':True,'version':'2.0.0','model':MODEL_SIZE,'device':DEVICE,'max_upload_mb':MAX_BYTES//1024//1024,'ffmpeg': bool(shutil_which('ffmpeg'))}

def shutil_which(name):
    import shutil; return shutil.which(name)

@app.post('/api/transcribe')
async def transcribe(file:UploadFile=File(...), language:str=Form('auto'), api_key:Optional[str]=Header(None,alias='X-API-Key')):
    auth(api_key)
    suffix=Path(file.filename or 'input.mp4').suffix or '.mp4'
    fd,path=tempfile.mkstemp(suffix=suffix); os.close(fd); size=0
    try:
        with open(path,'wb') as out:
            while True:
                chunk=await file.read(1024*1024)
                if not chunk: break
                size += len(chunk)
                if size>MAX_BYTES: raise HTTPException(413,f'File exceeds {MAX_BYTES//1024//1024} MB limit')
                out.write(chunk)
        segments,info=get_model().transcribe(path,language=None if language=='auto' else language,beam_size=5,vad_filter=True,word_timestamps=True,condition_on_previous_text=True)
        caps=[]; words=[]
        for seg in segments:
            text=' '.join(seg.text.strip().split())
            if text: caps.append({'id':str(uuid.uuid4()),'start':round(float(seg.start),3),'end':round(float(seg.end),3),'text':text})
            for w in seg.words or []:
                words.append({'start':round(float(w.start),3),'end':round(float(w.end),3),'text':w.word.strip()})
        return {'success':True,'language':info.language,'language_probability':round(float(info.language_probability),3),'captions':caps,'words':words}
    finally:
        cleanup(Path(path))

@app.post('/api/export/mp4')
async def export_mp4(background_tasks:BackgroundTasks, video:UploadFile=File(...), captions_json:str=Form(...), style_json:str=Form('{}'), api_key:Optional[str]=Header(None,alias='X-API-Key')):
    auth(api_key)
    if not shutil_which('ffmpeg'): raise HTTPException(500,'FFmpeg is not installed on the server')
    job=uuid.uuid4().hex; vpath=OUT/f'{job}.input{Path(video.filename or "video.mp4").suffix or ".mp4"}'; spath=OUT/f'{job}.srt'; opath=OUT/f'{job}.mp4'
    try:
        data=json.loads(captions_json); style=json.loads(style_json or '{}')
        with open(vpath,'wb') as out:
            size=0
            while True:
                chunk=await video.read(1024*1024)
                if not chunk: break
                size+=len(chunk)
                if size>MAX_BYTES: raise HTTPException(413,'File too large')
                out.write(chunk)
        with open(spath,'w',encoding='utf-8') as f:
            for i,c in enumerate(data,1): f.write(f'{i}\n{ts(c["start"])} --> {ts(c["end"])}\n{c["text"]}\n\n')
        font=style.get('font','Arial').replace("'",''); size=style.get('fontSize',22); color=style.get('primaryColor','&H00FFFFFF').replace('#','&H00')
        vf=f"subtitles='{spath.as_posix()}':force_style='FontName={font},FontSize={size},PrimaryColour={color},OutlineColour=&HAA000000,BorderStyle=1,Outline=2,Alignment=2,MarginV=60'"
        cmd=['ffmpeg','-y','-i',str(vpath),'-vf',vf,'-c:a','copy','-movflags','+faststart',str(opath)]
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=3600)
        if p.returncode!=0: raise HTTPException(500,p.stderr[-2000:])
        background_tasks.add_task(cleanup,vpath); background_tasks.add_task(cleanup,spath)
        return FileResponse(opath,media_type='video/mp4',filename='captions_ai_export.mp4',background=background_tasks)
    except HTTPException: cleanup(vpath); cleanup(spath); cleanup(opath); raise
    except Exception as e: cleanup(vpath); cleanup(spath); cleanup(opath); raise HTTPException(500,str(e))
