# Captions AI Pro v2.0 — Full Stack Android

Bu paket kaynak koddur: Android uygulaması + gerçek Whisper transkripsiyon backend'i + FFmpeg MP4 export.

## Özellikler
- Video seçme ve Media3/ExoPlayer oynatma
- faster-whisper ile gerçek transkripsiyon
- Otomatik dil algılama; AZ/TR/RU/EN ve diğer seçili diller
- Segment ve kelime zamanlaması
- Canlı caption önizleme
- Caption metni, başlangıç ve bitiş süresi düzenleme
- Caption ekleme/silme
- 30 adımlı undo
- SRT export
- FFmpeg + libass ile altyazıyı videoya gömülü MP4 export
- Backend URL ve isteğe bağlı API key ayarı Android içinden
- `/health` sunucu kontrolü
- Upload boyutu sınırı ve timeout kontrolleri
- Docker Compose ile backend çalıştırma

## 1. Backend'i çalıştır

Bir VPS, bulut sunucusu veya Docker destekleyen bilgisayar gerekir. Telefonun kendisi ağır Whisper işlemini güvenilir biçimde çalıştırmak için önerilmez.

```bash
cd backend
docker compose up -d --build
```

Sunucu test:

```text
http://SUNUCU_IP:8000/health
```

İnternete açık kullanımda reverse proxy üzerinden HTTPS kullanın. Android uygulamasına HTTP yerine HTTPS adresini girin.

Örnek:

```text
https://captions-api.example.com
```

## 2. Android telefonda APK oluşturma

### Seçenek A — AndroidIDE
1. Android telefona AndroidIDE kurun.
2. Bu ZIP'i açın.
3. `android/` klasörünü AndroidIDE ile proje olarak açın.
4. Gradle senkronizasyonunun bitmesini bekleyin.
5. `Build > Build APK` seçin.
6. Oluşan APK'yı Android'de kurun.

### Seçenek B — Bilgisayar varsa
`android/` klasörünü Android Studio ile açın ve `Build APK` çalıştırın.

## 3. Uygulamayı ilk kez çalıştırma
1. Uygulamayı açın.
2. `⚙ AI Server` butonuna dokunun.
3. Backend'in HTTPS adresini girin.
4. Video seçin.
5. Dil seçin veya `auto` bırakın.
6. `Auto Captions` düğmesine basın.
7. Caption'ları düzenleyin.
8. `SRT` ile altyazı dosyası kaydedin veya `Export MP4` ile altyazıyı videoya gömün.

## Önemli
- `https://YOUR-SERVER.example.com` yer tutucudur; gerçek sunucu adresi girmeden AI çalışmaz.
- Backend CPU üzerinde çalışır; `small` model hız/doğruluk dengesi için varsayılandır. Güçlü GPU sunucusunda `WHISPER_DEVICE=cuda` ve uygun compute ayarı kullanılabilir.
- API key kullanmak için backend ortam değişkeni `API_KEY` ayarlayın ve aynı anahtarı uygulamadaki AI Server ekranına girin.
- Production için HTTPS, erişim sınırı, API key, loglama ve sunucu kaynak limitleri kullanılmalıdır.

## GitHub Actions ile Android telefondan APK oluşturma

Bu ZIP'i **GitHub deposunun kök dizinine** çıkarıp tüm dosyaları yükleyin. `.github/workflows/build-apk.yml` dosyası APK'yı otomatik derler.

1. GitHub'da yeni bir **boş repository** oluşturun.
2. ZIP'i telefonda çıkarın ve içindeki **tüm klasörleri ve dosyaları** repository'nin köküne yükleyin.
3. Repository sayfasında **Actions** sekmesine girin.
4. `Build Captions AI Pro APK` iş akışını açın.
5. **Run workflow** düğmesine basın.
6. İşlem tamamlanınca workflow sonucundaki **Artifacts** bölümünden `Captions-AI-Pro-debug-APK` dosyasını indirin.
7. ZIP'i çıkarın ve `app-debug.apk` dosyasını Android telefonunuza kurun.

Not: İlk GitHub build'i birkaç dakika sürebilir. Build kırmızı olursa Actions ekranındaki hata günlüğünü ChatGPT'ye gönderin.
