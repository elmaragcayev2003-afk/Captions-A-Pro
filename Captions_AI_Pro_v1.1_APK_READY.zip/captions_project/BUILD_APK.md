# Captions AI Pro — APK build

Bu paket, Gradle Wrapper dosyası olmadan da GitHub Actions üzerinden APK üretecek şekilde hazırlanmıştır.

## GitHub ile APK üretme

1. ZIP'i GitHub deposuna çıkarılmış dosyalar halinde yükle.
2. `.github/workflows/build-apk.yml` dosyasının bulunduğunu kontrol et.
3. GitHub'da **Actions → Build Captions AI Pro APK** bölümüne gir.
4. **Run workflow** seçeneğine bas.
5. İşlem başarılı olduğunda workflow sayfasının **Artifacts** bölümünden `Captions-AI-Pro-debug-apk` dosyasını indir.

Bu yöntem `gradlew` gerektirmez; GitHub Actions Gradle 8.9'u kendisi hazırlar.

## Önemli: AI transkripsiyon backend'i

APK tek başına Whisper transkripsiyonu çalıştırmaz. Uygulama, FastAPI backend'ine bağlanır. Uygulamayı açtıktan sonra **AI Sunucusu** bölümünden telefonun erişebildiği HTTPS backend adresini ve gerekiyorsa API anahtarını gir.

Varsayılan backend adresi kod içinde bilerek örnek değer olarak bırakılmıştır; gerçek sunucu adresi uygulama içinden değiştirilebilir.
