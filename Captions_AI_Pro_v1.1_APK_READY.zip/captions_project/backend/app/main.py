import json
import os
import shutil
import subprocess
import tempfile
import threading
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from faster_whisper import WhisperModel

APP_VERSION = "1.1.0"
MODEL_SIZE = os.getenv("WHISPER_MODEL", "small")
DEVICE = os.getenv("WHISPER_DEVICE", "cpu")
COMPUTE = os.getenv("WHISPER_COMPUTE", "int8")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "750"))
API_KEY = os.getenv("CAPTIONS_API_KEY", "")

app = FastAPI(title="Captions AI Pro API", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",") if o.strip()],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

_model = None
_model_lock = threading.Lock()
_inference_lock = threading.Lock()


def check_key(x_api_key: str | None):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Geçersiz API anahtarı.")


def get_model():
    global _model
    if _model is None:
        with _model_lock:
            if _model is None:
                _model = WhisperModel(MODEL_SIZE, device=DEVICE, compute_type=COMPUTE)
    return _model


def save_upload(upload: UploadFile, path: str):
    total = 0
    with open(path, "wb") as out:
        while True:
            chunk = upload.file.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_UPLOAD_MB * 1024 * 1024:
                raise HTTPException(413, f"Dosya çok büyük. Maksimum {MAX_UPLOAD_MB} MB.")
            out.write(chunk)
    return total


def srt_timestamp(seconds: float) -> str:
    ms = max(0, int(round(seconds * 1000)))
    h, rem = divmod(ms, 3600000)
    m, rem = divmod(rem, 60000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def captions_to_srt(captions: list[dict]) -> str:
    rows = []
    for i, c in enumerate(captions, 1):
        text = " ".join(str(c.get("text", "")).split())
        if not text:
            continue
        start = float(c.get("start", 0))
        end = max(start + 0.05, float(c.get("end", start + 1)))
        rows.append(f"{i}\n{srt_timestamp(start)} --> {srt_timestamp(end)}\n{text}\n")
    return "\n".join(rows)


def ffmpeg_export(video_path: str, srt_path: str, output_path: str, font_size: int, position: str):
    # ASS/libass alignment: 2 bottom-center, 5 middle-center, 8 top-center.
    alignment = {"top": 8, "center": 5, "bottom": 2}.get(position, 2)
    # Escape characters relevant to the subtitles filter.
    escaped = srt_path.replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
    style = (
        f"FontName=Arial,FontSize={max(10, min(font_size, 64))},"
        "PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,"
        "BorderStyle=1,Outline=2,Shadow=1,Alignment=" + str(alignment)
    )
    cmd = [
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-i", video_path,
        "-vf", f"subtitles='{escaped}':force_style='{style}'",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart",
        output_path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    if result.returncode != 0:
        raise RuntimeError(result.stderr[-4000:] or "FFmpeg export başarısız.")


@app.get("/health")
def health():
    return {
        "ok": True,
        "app": "Captions AI Pro API",
        "version": APP_VERSION,
        "model": MODEL_SIZE,
        "device": DEVICE,
        "max_upload_mb": MAX_UPLOAD_MB,
        "export": shutil.which("ffmpeg") is not None,
    }


@app.post("/api/transcribe")
def transcribe(
    file: UploadFile = File(...),
    language: str = Form("auto"),
    x_api_key: str | None = Header(default=None),
):
    check_key(x_api_key)
    content_type = (file.content_type or "").lower()
    if not (content_type.startswith("video/") or content_type.startswith("audio/")):
        raise HTTPException(400, "Video veya ses dosyası gerekli.")

    suffix = Path(file.filename or "input.mp4").suffix or ".mp4"
    fd, path = tempfile.mkstemp(suffix=suffix)
    os.close(fd)
    try:
        save_upload(file, path)
        with _inference_lock:
            segments, info = get_model().transcribe(
                path,
                language=None if language == "auto" else language,
                beam_size=5,
                vad_filter=True,
                word_timestamps=True,
            )
            captions, words = [], []
            for seg in segments:
                text = " ".join(seg.text.strip().split())
                if text:
                    captions.append({
                        "id": len(captions) + 1,
                        "start": round(float(seg.start), 3),
                        "end": round(float(seg.end), 3),
                        "text": text,
                    })
                if seg.words:
                    for word in seg.words:
                        words.append({
                            "start": round(float(word.start), 3),
                            "end": round(float(word.end), 3),
                            "text": word.word,
                        })
        return {
            "success": True,
            "language": info.language,
            "language_probability": round(float(info.language_probability), 3),
            "duration": round(float(info.duration), 3),
            "captions": captions,
            "words": words,
        }
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


@app.post("/api/export")
def export_video(
    file: UploadFile = File(...),
    captions: str = Form(...),
    font_size: int = Form(20),
    position: str = Form("bottom"),
    x_api_key: str | None = Header(default=None),
):
    check_key(x_api_key)
    try:
        caption_list = json.loads(captions)
        if not isinstance(caption_list, list):
            raise ValueError
    except (ValueError, TypeError, json.JSONDecodeError):
        raise HTTPException(400, "Altyazı verisi geçersiz.")

    suffix = Path(file.filename or "input.mp4").suffix or ".mp4"
    work = Path(tempfile.mkdtemp(prefix="captions_export_"))
    video_path = work / f"input{suffix}"
    srt_path = work / "captions.srt"
    output_path = work / f"captions_ai_{uuid.uuid4().hex[:8]}.mp4"
    try:
        save_upload(file, str(video_path))
        srt_path.write_text(captions_to_srt(caption_list), encoding="utf-8")
        if not srt_path.read_text(encoding="utf-8").strip():
            raise HTTPException(400, "Dışa aktarılacak altyazı yok.")
        ffmpeg_export(str(video_path), str(srt_path), str(output_path), font_size, position)
        return FileResponse(
            str(output_path),
            media_type="video/mp4",
            filename="captions_ai_export.mp4",
            background=None,
        )
    except HTTPException:
        raise
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "Video dışa aktarma zaman aşımına uğradı.")
    except Exception as exc:
        raise HTTPException(500, f"Video dışa aktarılamadı: {exc}")
    finally:
        # FileResponse needs the file to remain until the response is sent; cleanup is
        # intentionally omitted here. A production deployment should add a janitor job.
        pass
