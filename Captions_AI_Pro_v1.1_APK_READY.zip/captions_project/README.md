# Captions AI Pro — v1.1 Full Stack

Gerçek video → Whisper transkripsiyon → zaman kodlu altyazı → Android düzenleme → SRT veya altyazısı videoya gömülü MP4.

## Proje yapısı

- `android/` — Kotlin Android uygulaması
- `backend/` — FastAPI + faster-whisper + FFmpeg
- `docker-compose.yml` — tek komutla backend çalıştırma

## Android tarafındaki yenilikler

- Modern Media3 1.11.0 video oynatma
- Video seçme
- Otomatik dil algılama + AZ/TR/RU/EN ve ek diller
- Gerçek Whisper transkripsiyonu
- Word-level timestamp backend tarafından döndürülür
- Satır metni düzenleme
- Başlangıç/bitiş saniyesi düzenleme
- Satır ekleme/silme
- Undo / Redo
- Canlı altyazı önizlemesi
- Font boyutu ve üst/orta/alt konum seçimi
- SRT export
- FFmpeg ile altyazısı videoya gömülü MP4 export
- Backend URL ve API key uygulama içinden değiştirilebilir
- Büyük dosyalar için streaming/chunked upload

Media3 1.11.0, Ağustos 2026 itibarıyla Android'in güncel stabil Media3 sürümüdür. Google ayrıca Compose ve medya düzenleme tarafında yeni Media3 yeteneklerini bu sürümde genişletmiştir.

## 1. Backend'i çalıştır

### Docker önerilir

```bash
cd Captions_AI_Pro_Full_Stack
cp backend/.env.example backend/.env
```

`backend/.env` içinde en azından `CAPTIONS_API_KEY` değerini güçlü rastgele bir değer yap.

Sonra:

```bash
docker compose up -d --build
```

Test:

```text
http://SUNUCU_IP:8000/health
```

Sunucu internete açılacaksa **HTTPS reverse proxy** (ör. Nginx/Caddy/Cloudflare Tunnel) kullanılması önerilir. Android uygulaması varsayılan olarak HTTPS bekler.

### GPU

NVIDIA GPU'lu bir sunucuda `WHISPER_DEVICE=cuda` ve uygun CUDA tabanlı Docker imajı kullanılabilir. CPU'da `small + int8` daha ekonomik bir başlangıçtır. Daha yüksek doğruluk için `medium` veya `large-v3` seçilebilir; bunlar daha fazla RAM/VRAM ve işlem süresi ister.

## 2. Android APK

`android/` klasörünü Android Studio'da aç.

Gradle senkronizasyonundan sonra:

```text
Build → Generate App Bundle / APK → Generate APK
```

APK kurulduktan sonra:

**⚙ → AI Sunucusu**

bölümünden backend'in HTTPS adresini gir.

Örneğin:

```text
https://api.senin-domainin.com
```

API key kullandıysan aynı ekrana gir.

## 3. İş akışı

1. `VIDEO SEÇ`
2. `✦ AI TRANSCRIBE`
3. Altyazı satırlarını düzenle
4. Font/konum seç
5. `SRT` ile ayrı altyazı çıkar veya `MP4` ile videoya göm

## Güvenlik

- Public backend'de API key kullan.
- HTTP yerine HTTPS kullan.
- `MAX_UPLOAD_MB` değerini ihtiyacına göre sınırla.
- Büyük ve çok kullanıcılı prodüksiyonda job queue + object storage eklenmesi önerilir.

## Not

Bu paket **backend'i otomatik olarak internete deploy etmez**; gerçek transkripsiyon için backend'in bir VPS/cloud sunucusunda çalışması gerekir. Android uygulamasında sunucu adresini sonradan değiştirebilirsin.

## APK build (GitHub Actions)

Bu sürümde `.github/workflows/build-apk.yml` bulunur. GitHub Actions, Gradle 8.9'u kendisi kurarak `android/` klasöründeki debug APK'yı üretir. Bu nedenle `gradlew` dosyasına ihtiyaç yoktur.
