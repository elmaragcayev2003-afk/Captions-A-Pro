package com.captionsai.pro

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.max

private data class Caption(var start: Double, var end: Double, var text: String)

class MainActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var status: TextView
    private lateinit var live: TextView
    private lateinit var list: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var language: Spinner
    private lateinit var position: Spinner
    private lateinit var fontSize: SeekBar
    private lateinit var prefs: SharedPreferences

    private var videoUri: Uri? = null
    private val captions = mutableListOf<Caption>()
    private val undoStack = ArrayDeque<List<Caption>>()
    private val redoStack = ArrayDeque<List<Caption>>()
    private var pendingSrt = ""

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            videoUri = uri
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            status.text = "Video hazır • AI analize başlayabilirsin"
            findViewById<Button>(R.id.analyze).isEnabled = true
            findViewById<Button>(R.id.export).isEnabled = false
        }
    }

    private val srtSaver = registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        if (uri != null) lifecycleScope.launch(Dispatchers.IO) {
            contentResolver.openOutputStream(uri)?.use { it.write(pendingSrt.toByteArray(Charsets.UTF_8)) }
            withContext(Dispatchers.Main) { status.text = "SRT kaydedildi" }
        }
    }

    private val videoSaver = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        if (uri != null) exportVideo(uri)
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("captions_ai", MODE_PRIVATE)

        status = findViewById(R.id.status)
        live = findViewById(R.id.liveCaption)
        list = findViewById(R.id.captionList)
        progress = findViewById(R.id.progress)
        language = findViewById(R.id.language)
        position = findViewById(R.id.position)
        fontSize = findViewById(R.id.fontSize)

        player = ExoPlayer.Builder(this).build()
        findViewById<androidx.media3.ui.PlayerView>(R.id.player).player = player

        language.adapter = spinnerAdapter(arrayOf("auto", "az", "tr", "ru", "en", "de", "fr", "es"))
        position.adapter = spinnerAdapter(arrayOf("bottom", "center", "top"))
        fontSize.progress = 10
        findViewById<TextView>(R.id.fontLabel).text = "Font: 20"
        fontSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                findViewById<TextView>(R.id.fontLabel).text = "Font: ${value + 10}"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        findViewById<Button>(R.id.pick).setOnClickListener { picker.launch(arrayOf("video/*")) }
        findViewById<Button>(R.id.analyze).setOnClickListener { analyze(language.selectedItem.toString()) }
        findViewById<Button>(R.id.add).setOnClickListener {
            snapshot()
            captions.add(Caption(player.currentPosition / 1000.0, player.currentPosition / 1000.0 + 2.0, "Yeni altyazı"))
            render()
        }
        findViewById<Button>(R.id.undo).setOnClickListener { undo() }
        findViewById<Button>(R.id.redo).setOnClickListener { redo() }
        findViewById<Button>(R.id.srt).setOnClickListener {
            pendingSrt = buildSrt()
            srtSaver.launch("captions_ai.srt")
        }
        findViewById<Button>(R.id.export).setOnClickListener { videoSaver.launch("captions_ai_export.mp4") }
        findViewById<Button>(R.id.server).setOnClickListener { showServerDialog() }

        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { if (isPlaying) tick() }
        })
        status.text = "Hazır • Sunucu: ${baseUrl()}"
    }

    private fun spinnerAdapter(items: Array<String>) = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)

    private fun baseUrl(): String = prefs.getString("base_url", "https://YOUR-SERVER.example.com")!!.trim().trimEnd('/')
    private fun apiKey(): String = prefs.getString("api_key", "")!!.trim()

    private fun showServerDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 8, 32, 0) }
        val url = EditText(this).apply { hint = "https://api.example.com"; setText(baseUrl()) }
        val key = EditText(this).apply { hint = "API key (opsiyonel)"; setText(apiKey()); inputType = 0x00000081 }
        box.addView(url); box.addView(key)
        AlertDialog.Builder(this).setTitle("AI Sunucusu")
            .setMessage("Telefonun erişebildiği HTTPS FastAPI adresini gir.")
            .setView(box)
            .setNegativeButton("İptal", null)
            .setPositiveButton("Kaydet") { _, _ ->
                prefs.edit().putString("base_url", url.text.toString().trim().trimEnd('/')).putString("api_key", key.text.toString().trim()).apply()
                status.text = "Sunucu kaydedildi • ${baseUrl()}"
            }.show()
    }

    private fun tick() {
        live.postDelayed(object : Runnable {
            override fun run() {
                val t = player.currentPosition / 1000.0
                val current = captions.firstOrNull { t >= it.start && t < it.end }
                live.text = current?.text ?: ""
                live.textSize = (fontSize.progress + 10).toFloat()
                if (player.isPlaying) live.postDelayed(this, 80)
            }
        }, 80)
    }

    private fun analyze(lang: String) {
        val uri = videoUri ?: return
        lifecycleScope.launch {
            setBusy(true, "AI transkripsiyon yapılıyor…")
            try {
                val result = withContext(Dispatchers.IO) { uploadMultipart("/api/transcribe", uri, lang) }
                val arr = result.getJSONArray("captions")
                snapshot()
                captions.clear()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    captions.add(Caption(o.getDouble("start"), o.getDouble("end"), o.getString("text")))
                }
                render()
                status.text = "Tamamlandı • ${captions.size} satır • ${result.optString("language", "?")}"
            } catch (e: Exception) {
                status.text = "Hata: ${friendlyError(e)}"
            } finally { setBusy(false, status.text.toString()) }
        }
    }

    private fun uploadMultipart(path: String, uri: Uri, languageValue: String): JSONObject {
        val boundary = "----CaptionsAI${System.currentTimeMillis()}"
        val conn = openConnection(path)
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        conn.setChunkedStreamingMode(1024 * 1024)
        conn.outputStream.use { raw ->
            val out = BufferedOutputStream(raw)
            writePart(out, boundary, "language", null, "text/plain", languageValue.toByteArray())
            val name = "video.mp4"
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"$name\"\r\nContent-Type: video/mp4\r\n\r\n".toByteArray())
            contentResolver.openInputStream(uri)?.use { input -> input.copyTo(out, 1024 * 1024) } ?: throw Exception("Video okunamadı")
            out.write("\r\n--$boundary--\r\n".toByteArray())
            out.flush()
        }
        return readJson(conn)
    }

    private fun exportVideo(targetUri: Uri) {
        val uri = videoUri ?: return
        if (captions.isEmpty()) { status.text = "Önce altyazı oluştur."; return }
        lifecycleScope.launch {
            setBusy(true, "Video dışa aktarılıyor…")
            try {
                val result = withContext(Dispatchers.IO) { exportRequest(uri) }
                contentResolver.openOutputStream(targetUri)?.use { out -> result.copyTo(BufferedOutputStream(out), 1024 * 1024) }
                status.text = "MP4 hazır • Altyazı videoya gömüldü"
            } catch (e: Exception) {
                status.text = "Export hatası: ${friendlyError(e)}"
            } finally { setBusy(false, status.text.toString()) }
        }
    }

    private fun exportRequest(uri: Uri): BufferedInputStream {
        val boundary = "----CaptionsExport${System.currentTimeMillis()}"
        val conn = openConnection("/api/export")
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        conn.setChunkedStreamingMode(1024 * 1024)
        val json = JSONArray().apply {
            captions.forEachIndexed { i, c -> put(JSONObject().apply { put("id", i + 1); put("start", c.start); put("end", c.end); put("text", c.text) }) }
        }
        conn.outputStream.use { raw ->
            val out = BufferedOutputStream(raw)
            writePart(out, boundary, "captions", null, "application/json", json.toString().toByteArray())
            writePart(out, boundary, "font_size", null, "text/plain", (fontSize.progress + 10).toString().toByteArray())
            writePart(out, boundary, "position", null, "text/plain", position.selectedItem.toString().toByteArray())
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"video.mp4\"\r\nContent-Type: video/mp4\r\n\r\n".toByteArray())
            contentResolver.openInputStream(uri)?.use { it.copyTo(out, 1024 * 1024) } ?: throw Exception("Video okunamadı")
            out.write("\r\n--$boundary--\r\n".toByteArray()); out.flush()
        }
        if (conn.responseCode !in 200..299) throw Exception(conn.errorStream?.bufferedReader()?.readText() ?: "HTTP ${conn.responseCode}")
        return BufferedInputStream(conn.inputStream)
    }

    private fun writePart(out: BufferedOutputStream, boundary: String, name: String, filename: String?, contentType: String, data: ByteArray) {
        val filePart = if (filename != null) "; filename=\"$filename\"" else ""
        out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"$filePart\r\nContent-Type: $contentType\r\n\r\n".toByteArray())
        out.write(data); out.write("\r\n".toByteArray())
    }

    private fun openConnection(path: String): HttpURLConnection {
        val url = URL(baseUrl() + path)
        return (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 3_600_000
            setRequestProperty("Accept", "application/json, video/mp4")
            if (apiKey().isNotEmpty()) setRequestProperty("X-API-Key", apiKey())
        }
    }

    private fun readJson(conn: HttpURLConnection): JSONObject {
        if (conn.responseCode !in 200..299) throw Exception(conn.errorStream?.bufferedReader()?.readText() ?: "HTTP ${conn.responseCode}")
        return JSONObject(conn.inputStream.bufferedReader().readText())
    }

    private fun snapshot() {
        undoStack.addLast(captions.map { it.copy() })
        if (undoStack.size > 30) undoStack.removeFirst()
        redoStack.clear()
    }

    private fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(captions.map { it.copy() })
        captions.clear(); captions.addAll(undoStack.removeLast().map { it.copy() }); render()
    }

    private fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(captions.map { it.copy() })
        captions.clear(); captions.addAll(redoStack.removeLast().map { it.copy() }); render()
    }

    private fun render() {
        list.removeAllViews()
        captions.forEachIndexed { index, caption ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 10, 14, 10)
                setBackgroundResource(R.drawable.caption_card)
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val start = numberEdit(caption.start)
            val end = numberEdit(caption.end)
            val text = EditText(this).apply {
                setText(caption.text); setSingleLine(false); hint = "Altyazı metni"; textSize = 16f
                addTextChangedListener(SimpleTextWatcher { caption.text = it; findViewById<Button>(R.id.export).isEnabled = captions.isNotEmpty() })
            }
            start.addTextChangedListener(SimpleTextWatcher { caption.start = it.toDoubleOrNull() ?: caption.start })
            end.addTextChangedListener(SimpleTextWatcher { caption.end = max(caption.start + 0.05, it.toDoubleOrNull() ?: caption.end) })
            row.addView(start, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(end, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val del = Button(this).apply { text = "Sil"; setOnClickListener { snapshot(); captions.removeAt(index); render() } }
            card.addView(row)
            card.addView(text)
            card.addView(del)
            list.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 8, 0, 8) })
        }
        findViewById<Button>(R.id.export).isEnabled = captions.isNotEmpty() && videoUri != null
    }

    private fun numberEdit(value: Double) = EditText(this).apply {
        setText("%.2f".format(value)); inputType = 2 or 8192; hint = "saniye"; gravity = Gravity.CENTER
    }

    private fun buildSrt(): String = captions.mapIndexed { i, c ->
        "${i + 1}\n${fmt(c.start)} --> ${fmt(c.end)}\n${c.text.trim()}\n"
    }.joinToString("\n")

    private fun fmt(v: Double): String {
        val ms = max(0, (v * 1000).toLong()); val h = ms / 3600000
        val m = (ms % 3600000) / 60000; val s = (ms % 60000) / 1000; val x = ms % 1000
        return "%02d:%02d:%02d,%03d".format(h, m, s, x)
    }

    private fun setBusy(busy: Boolean, message: String) {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        findViewById<Button>(R.id.pick).isEnabled = !busy
        findViewById<Button>(R.id.analyze).isEnabled = !busy && videoUri != null
        findViewById<Button>(R.id.export).isEnabled = !busy && captions.isNotEmpty() && videoUri != null
        status.text = message
    }

    private fun friendlyError(e: Exception): String = when {
        e.message?.contains("Unable to resolve host", true) == true -> "Sunucu adresine ulaşılamadı. Ayarlardan HTTPS adresini kontrol et."
        e.message?.contains("401") == true -> "API anahtarı geçersiz."
        e.message?.contains("413") == true -> "Video sunucunun izin verdiği boyuttan büyük."
        else -> (e.message ?: e.javaClass.simpleName).take(500)
    }

    override fun onDestroy() { player.release(); super.onDestroy() }
}

private class SimpleTextWatcher(private val onChanged: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onChanged(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) = Unit
}
